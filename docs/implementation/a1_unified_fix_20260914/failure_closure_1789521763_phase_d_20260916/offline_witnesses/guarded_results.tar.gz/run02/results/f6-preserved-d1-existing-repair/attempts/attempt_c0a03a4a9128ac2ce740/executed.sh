#!/bin/bash
set +e
: > /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/stdout.log
: > /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/approved.sh > /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/command_trace.log
/usr/bin/bash -o pipefail /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/approved.sh > /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/stdout.log 2> /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_c0a03a4a9128ac2ce740","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/exit_status.json.tmp.$$'
mv '/tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/exit_status.json.tmp.$$' /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-apor7hdz/task_outputs/fix-f6-normal/attempts/attempt_c0a03a4a9128ac2ce740/exit_status.json
exit "$rc"
