#!/bin/sh
# Inspection stopped; this file does not rerun scientific commands.
# Stop identity: managed-stop:7e71b7a6a9faaa08401badbfeacc1008f3d90d25afb440bcb1195ba826782d5b
# Task: fix-f6-aba
# Executed attempt: ; formal step commit is pending.
# Exact executed command body is not available in this bounded stop; it has not been reconstructed.
# Unfinished: check_contig_compatibility (failed)
# Unfinished: prepare_database (pending)
# Unfinished: build_database (pending)
# Unfinished: annotate_variants (pending)
# Unfinished: summarize_ann (pending)
# Unfinished: finalize_outputs (pending)
exit 1
