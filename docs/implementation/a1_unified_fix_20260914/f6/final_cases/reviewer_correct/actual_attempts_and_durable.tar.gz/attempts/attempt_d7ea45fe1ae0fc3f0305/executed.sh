#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/stdout.log
: > /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/approved.sh > /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/approved.sh > /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/stdout.log 2> /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_d7ea45fe1ae0fc3f0305","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_d7ea45fe1ae0fc3f0305/exit_status.json
exit "$rc"
