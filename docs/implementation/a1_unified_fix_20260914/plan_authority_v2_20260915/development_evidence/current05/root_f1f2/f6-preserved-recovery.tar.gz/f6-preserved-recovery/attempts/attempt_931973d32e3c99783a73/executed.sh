#!/bin/bash
set +e
: > /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/stdout.log
: > /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/approved.sh > /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/approved.sh > /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/stdout.log 2> /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_931973d32e3c99783a73","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/exit_status.json.tmp.$$'
mv '/tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/exit_status.json.tmp.$$' /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-zixb896g/task_outputs/fix-f6-recovery/attempts/attempt_931973d32e3c99783a73/exit_status.json
exit "$rc"
