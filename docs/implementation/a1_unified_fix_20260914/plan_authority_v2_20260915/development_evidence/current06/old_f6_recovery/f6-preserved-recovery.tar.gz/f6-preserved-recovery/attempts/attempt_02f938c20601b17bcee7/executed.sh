#!/bin/bash
set +e
: > /tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/stdout.log
: > /tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/approved.sh > /tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/approved.sh > /tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/stdout.log 2> /tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_02f938c20601b17bcee7","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/exit_status.json.tmp.$$'
mv '/tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/exit_status.json.tmp.$$' /tmp/biomind-plan-authority-v2-current06/old_f6_recovery/scratch/biomind-plan-local-graph-6np7csps/task_outputs/fix-f6-recovery/attempts/attempt_02f938c20601b17bcee7/exit_status.json
exit "$rc"
