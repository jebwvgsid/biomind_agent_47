#!/bin/bash
set +e
: > /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/stdout.log
: > /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/approved.sh > /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/approved.sh > /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/stdout.log 2> /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_10d9efb645256f4f6d07","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/exit_status.json.tmp.$$'
mv '/tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/exit_status.json.tmp.$$' /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-pfpnsbrm/task_outputs/fix-f6-6793_class_last/attempts/attempt_10d9efb645256f4f6d07/exit_status.json
exit "$rc"
