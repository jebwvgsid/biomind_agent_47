#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/stdout.log
: > /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/approved.sh > /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/approved.sh > /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/stdout.log 2> /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_6b2c8f9ca7be24bb58a5","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_6b2c8f9ca7be24bb58a5/exit_status.json
exit "$rc"
