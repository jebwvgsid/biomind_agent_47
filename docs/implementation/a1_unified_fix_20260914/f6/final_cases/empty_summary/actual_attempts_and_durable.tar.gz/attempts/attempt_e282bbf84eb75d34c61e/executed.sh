#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/stdout.log
: > /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/approved.sh > /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/approved.sh > /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/stdout.log 2> /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_e282bbf84eb75d34c61e","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-empty_summary/scratch/biomind-plan-local-graph-d34eqlka/task_outputs/fix-f6-empty_summary/attempts/attempt_e282bbf84eb75d34c61e/exit_status.json
exit "$rc"
