#!/bin/bash
set +e
: > /tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/stdout.log
: > /tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/approved.sh > /tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/approved.sh > /tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/stdout.log 2> /tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_a3d27e1a623127ba4fac","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/exit_status.json.tmp.$$'
mv '/tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/exit_status.json.tmp.$$' /tmp/biomind-plan-authority-v2-current07/protection/f3_reload/scratch/biomind-plan-local-graph-uvw1_bmq/task_outputs/fix-f6-recovery/attempts/attempt_a3d27e1a623127ba4fac/exit_status.json
exit "$rc"
