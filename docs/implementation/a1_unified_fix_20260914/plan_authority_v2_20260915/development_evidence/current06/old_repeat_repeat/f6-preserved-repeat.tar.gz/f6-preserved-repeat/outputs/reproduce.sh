#!/bin/sh
# Inspection stopped; this file does not rerun scientific commands.
# Stop identity: managed-stop:17b38792c864a622e2d988b0cf02a97c32782d4202da4a86db136577b0a10ee3
# Task: fix-f6-repeat
# Executed attempt: ; formal step commit is pending.
# Exact executed command body is not available in this bounded stop; it has not been reconstructed.
# Unfinished: check_contig_compatibility (failed)
# Unfinished: prepare_database (pending)
# Unfinished: build_database (pending)
# Unfinished: annotate_variants (pending)
# Unfinished: summarize_ann (pending)
# Unfinished: finalize_outputs (pending)
exit 1
