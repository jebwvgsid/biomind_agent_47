#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/stdout.log
: > /tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/approved.sh > /tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/approved.sh > /tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/stdout.log 2> /tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_c6b39a919e1f8be63887","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-reviewer_exhaust/scratch/biomind-plan-local-graph-tbwrx295/task_outputs/fix-f6-reviewer_exhaust/attempts/attempt_c6b39a919e1f8be63887/exit_status.json
exit "$rc"
