#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/stdout.log
: > /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/approved.sh > /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/approved.sh > /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/stdout.log 2> /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_c55eb5254055a6f7a2d6","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_c55eb5254055a6f7a2d6/exit_status.json
exit "$rc"
