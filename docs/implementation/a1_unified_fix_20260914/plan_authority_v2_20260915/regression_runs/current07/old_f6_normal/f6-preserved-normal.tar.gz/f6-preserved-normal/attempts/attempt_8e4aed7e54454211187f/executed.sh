#!/bin/bash
set +e
: > /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/stdout.log
: > /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/approved.sh > /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/approved.sh > /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/stdout.log 2> /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_8e4aed7e54454211187f","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/exit_status.json.tmp.$$'
mv '/tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/exit_status.json.tmp.$$' /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_8e4aed7e54454211187f/exit_status.json
exit "$rc"
