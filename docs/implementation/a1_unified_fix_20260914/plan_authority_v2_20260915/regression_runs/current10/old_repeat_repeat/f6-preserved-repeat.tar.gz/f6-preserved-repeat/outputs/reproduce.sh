#!/bin/sh
# Inspection stopped; this file does not rerun scientific commands.
# Stop identity: managed-stop:12d64fc41c659e01c69a2ccb482bfe427778c89f82b40098c244ead806159d55
# Task: fix-f6-repeat
# Executed attempt: ; formal step commit is pending.
# Exact executed command body is not available in this bounded stop; it has not been reconstructed.
# Unfinished: check_contig_compatibility (failed)
# Unfinished: prepare_database (pending)
# Unfinished: build_database (pending)
# Unfinished: annotate_variants (pending)
# Unfinished: summarize_ann (pending)
# Unfinished: finalize_outputs (pending)
exit 1
