#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/stdout.log
: > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/approved.sh > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/approved.sh > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/stdout.log 2> /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_1d9afd3486eba69e03cf","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_1d9afd3486eba69e03cf/exit_status.json
exit "$rc"
