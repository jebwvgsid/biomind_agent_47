#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/stdout.log
: > /tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/approved.sh > /tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/approved.sh > /tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/stdout.log 2> /tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_e873256be02caae1a005","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-reviewer_veto/scratch/biomind-plan-local-graph-i5cgwcbd/task_outputs/fix-f6-reviewer_veto/attempts/attempt_e873256be02caae1a005/exit_status.json
exit "$rc"
