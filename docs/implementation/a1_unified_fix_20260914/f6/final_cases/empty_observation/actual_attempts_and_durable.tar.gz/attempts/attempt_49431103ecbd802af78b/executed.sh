#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/stdout.log
: > /tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/approved.sh > /tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/approved.sh > /tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/stdout.log 2> /tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_49431103ecbd802af78b","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-empty_observation/scratch/biomind-plan-local-graph-qsufv2ph/task_outputs/fix-f6-empty_observation/attempts/attempt_49431103ecbd802af78b/exit_status.json
exit "$rc"
