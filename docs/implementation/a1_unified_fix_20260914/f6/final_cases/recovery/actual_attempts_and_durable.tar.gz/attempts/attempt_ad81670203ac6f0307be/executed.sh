#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/stdout.log
: > /tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/approved.sh > /tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/approved.sh > /tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/stdout.log 2> /tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_ad81670203ac6f0307be","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-recovery/scratch/biomind-plan-local-graph-ho3pf7f2/task_outputs/fix-f6-recovery/attempts/attempt_ad81670203ac6f0307be/exit_status.json
exit "$rc"
