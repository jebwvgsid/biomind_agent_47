#!/bin/bash
set +e
: > /tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/stdout.log
: > /tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/approved.sh > /tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/approved.sh > /tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/stdout.log 2> /tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_6ff3feae2f0df32bd4dd","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/exit_status.json.tmp.$$'
mv '/tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/exit_status.json.tmp.$$' /tmp/biomind-plan-authority-v2-current07/old_f6_recovery/scratch/biomind-plan-local-graph-5auzuzcs/task_outputs/fix-f6-recovery/attempts/attempt_6ff3feae2f0df32bd4dd/exit_status.json
exit "$rc"
