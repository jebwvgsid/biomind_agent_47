#!/bin/bash
set +e
: > /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/stdout.log
: > /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/approved.sh > /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/command_trace.log
/usr/bin/bash -o pipefail /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/approved.sh > /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/stdout.log 2> /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_d817becf7f46e01e7979","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/exit_status.json.tmp.$$'
mv '/tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/exit_status.json.tmp.$$' /tmp/bm_failure_closure_d_run02/results/scratch/biomind-plan-local-graph-yy8ullxi/task_outputs/fix-f6-d1-unresolved-preapproval/attempts/attempt_d817becf7f46e01e7979/exit_status.json
exit "$rc"
