#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/stdout.log
: > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/approved.sh > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/approved.sh > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/stdout.log 2> /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_2de60c3645847c2b8348","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_2de60c3645847c2b8348/exit_status.json
exit "$rc"
