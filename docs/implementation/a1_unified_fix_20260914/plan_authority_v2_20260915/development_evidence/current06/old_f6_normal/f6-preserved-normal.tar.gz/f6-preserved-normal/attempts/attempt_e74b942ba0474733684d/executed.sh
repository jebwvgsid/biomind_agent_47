#!/bin/bash
set +e
: > /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/stdout.log
: > /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/approved.sh > /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/approved.sh > /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/stdout.log 2> /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_e74b942ba0474733684d","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/exit_status.json.tmp.$$'
mv '/tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/exit_status.json.tmp.$$' /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_e74b942ba0474733684d/exit_status.json
exit "$rc"
