#!/bin/sh
# Inspection stopped; this file does not rerun scientific commands.
# Stop identity: managed-stop:0b30598a3925697fd39981721f750027298556039146b94151935fc4e9d79ad1
# Task: fix-f6-voluntary_stop
# Executed attempt: ; formal step commit is pending.
# Exact executed command body is not available in this bounded stop; it has not been reconstructed.
# Unfinished: prepare_database (running)
# Unfinished: build_database (pending)
# Unfinished: annotate_variants (pending)
# Unfinished: summarize_ann (pending)
# Unfinished: finalize_outputs (pending)
exit 1
