#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/stdout.log
: > /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/approved.sh > /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/approved.sh > /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/stdout.log 2> /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_f8d352cfb879c787be0c","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-reviewer_correct/scratch/biomind-plan-local-graph-b2g3o6qy/task_outputs/fix-f6-reviewer_correct/attempts/attempt_f8d352cfb879c787be0c/exit_status.json
exit "$rc"
