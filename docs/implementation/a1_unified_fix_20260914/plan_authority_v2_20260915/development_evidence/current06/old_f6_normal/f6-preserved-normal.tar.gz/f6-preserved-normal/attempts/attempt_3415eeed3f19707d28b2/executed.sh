#!/bin/bash
set +e
: > /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/stdout.log
: > /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/approved.sh > /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/approved.sh > /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/stdout.log 2> /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_3415eeed3f19707d28b2","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/exit_status.json.tmp.$$'
mv '/tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/exit_status.json.tmp.$$' /tmp/biomind-plan-authority-v2-current06/old_f6_normal/scratch/biomind-plan-local-graph-qjjtgj7g/task_outputs/fix-f6-normal/attempts/attempt_3415eeed3f19707d28b2/exit_status.json
exit "$rc"
