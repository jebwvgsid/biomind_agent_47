#!/bin/sh
# Inspection stopped; this file does not rerun scientific commands.
# Stop identity: managed-stop:00017a1f85beb354805a92c7dc3632e427dce3e328f46e87f2c99c96ed33a6ab
# Task: fix-f6-aba
# Executed attempt: ; formal step commit is pending.
# Exact executed command body is not available in this bounded stop; it has not been reconstructed.
# Unfinished: check_contig_compatibility (failed)
# Unfinished: prepare_database (pending)
# Unfinished: build_database (pending)
# Unfinished: annotate_variants (pending)
# Unfinished: summarize_ann (pending)
# Unfinished: finalize_outputs (pending)
exit 1
