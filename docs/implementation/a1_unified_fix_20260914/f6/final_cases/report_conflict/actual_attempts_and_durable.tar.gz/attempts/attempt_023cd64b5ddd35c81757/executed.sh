#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/stdout.log
: > /tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/approved.sh > /tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/approved.sh > /tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/stdout.log 2> /tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_023cd64b5ddd35c81757","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-report_conflict/scratch/biomind-plan-local-graph-p3eobggq/task_outputs/fix-f6-report_conflict/attempts/attempt_023cd64b5ddd35c81757/exit_status.json
exit "$rc"
