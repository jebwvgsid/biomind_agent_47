#!/bin/sh
# Inspection stopped; this file does not rerun scientific commands.
# Stop identity: managed-stop:e16d7ee199e7b3392d9f9b8a019ee4207ede89e329fcdb00291d5ace7a386d4b
# Task: fix-f6-voluntary_stop
# Executed attempt: ; formal step commit is pending.
# Exact executed command body is not available in this bounded stop; it has not been reconstructed.
# Unfinished: prepare_database (running)
# Unfinished: build_database (pending)
# Unfinished: annotate_variants (pending)
# Unfinished: summarize_ann (pending)
# Unfinished: finalize_outputs (pending)
exit 1
