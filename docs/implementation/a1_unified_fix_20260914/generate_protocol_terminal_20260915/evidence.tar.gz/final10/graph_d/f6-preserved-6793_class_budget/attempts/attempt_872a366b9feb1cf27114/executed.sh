#!/bin/bash
set +e
: > /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/stdout.log
: > /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/approved.sh > /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/approved.sh > /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/stdout.log 2> /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_872a366b9feb1cf27114","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/exit_status.json.tmp.$$'
mv '/tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/exit_status.json.tmp.$$' /tmp/biomind-generate-class-20260915/final10/graph_d/scratch/biomind-plan-local-graph-wpum34kh/task_outputs/fix-f6-6793_class_budget/attempts/attempt_872a366b9feb1cf27114/exit_status.json
exit "$rc"
