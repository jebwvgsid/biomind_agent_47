#!/bin/bash
set +e
: > /tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/stdout.log
: > /tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/approved.sh > /tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/approved.sh > /tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/stdout.log 2> /tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_1defbef679134535b783","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/exit_status.json.tmp.$$'
mv '/tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/exit_status.json.tmp.$$' /tmp/biomind-generate-class-20260915/final10/protections/scratch/biomind-plan-local-graph-gblga6h7/task_outputs/fix-f6-recovery/attempts/attempt_1defbef679134535b783/exit_status.json
exit "$rc"
