#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/stdout.log
: > /tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/approved.sh > /tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/approved.sh > /tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/stdout.log 2> /tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_92ecd432fb5db0fe5e5e","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-voluntary_stop/scratch/biomind-plan-local-graph-5in_2kys/task_outputs/fix-f6-voluntary_stop/attempts/attempt_92ecd432fb5db0fe5e5e/exit_status.json
exit "$rc"
