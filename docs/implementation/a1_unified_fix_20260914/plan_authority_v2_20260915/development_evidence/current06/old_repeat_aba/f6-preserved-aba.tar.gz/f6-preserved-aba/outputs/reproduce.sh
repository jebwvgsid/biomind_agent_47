#!/bin/sh
# Inspection stopped; this file does not rerun scientific commands.
# Stop identity: managed-stop:95a1e3581f46274e3c87f8cb79ac3a2328cd5ae9428c88ad5eab77a1288ae07c
# Task: fix-f6-aba
# Executed attempt: ; formal step commit is pending.
# Exact executed command body is not available in this bounded stop; it has not been reconstructed.
# Unfinished: check_contig_compatibility (failed)
# Unfinished: prepare_database (pending)
# Unfinished: build_database (pending)
# Unfinished: annotate_variants (pending)
# Unfinished: summarize_ann (pending)
# Unfinished: finalize_outputs (pending)
exit 1
