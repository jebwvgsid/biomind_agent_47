#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/stdout.log
: > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/approved.sh > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/approved.sh > /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/stdout.log 2> /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_64203fff19d7b2ae4436","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-normal/scratch/biomind-plan-local-graph-zx3cejby/task_outputs/fix-f6-normal/attempts/attempt_64203fff19d7b2ae4436/exit_status.json
exit "$rc"
