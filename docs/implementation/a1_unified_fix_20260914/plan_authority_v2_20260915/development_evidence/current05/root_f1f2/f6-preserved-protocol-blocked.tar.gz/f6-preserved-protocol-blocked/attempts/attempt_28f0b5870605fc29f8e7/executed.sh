#!/bin/bash
set +e
: > /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/stdout.log
: > /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/approved.sh > /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/approved.sh > /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/stdout.log 2> /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_28f0b5870605fc29f8e7","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/exit_status.json.tmp.$$'
mv '/tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/exit_status.json.tmp.$$' /tmp/biomind-plan-authority-v2-current05/root_f1f2/scratch/biomind-plan-local-graph-7b_wy2ro/task_outputs/fix-f6-protocol-blocked/attempts/attempt_28f0b5870605fc29f8e7/exit_status.json
exit "$rc"
