#!/bin/bash
set +e
: > /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/stdout.log
: > /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/approved.sh > /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/approved.sh > /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/stdout.log 2> /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_54abcbcba1c707602b33","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/exit_status.json.tmp.$$'
mv '/tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/exit_status.json.tmp.$$' /tmp/biomind-plan-authority-v2-current07/old_f6_normal/scratch/biomind-plan-local-graph-u_l35o08/task_outputs/fix-f6-normal/attempts/attempt_54abcbcba1c707602b33/exit_status.json
exit "$rc"
