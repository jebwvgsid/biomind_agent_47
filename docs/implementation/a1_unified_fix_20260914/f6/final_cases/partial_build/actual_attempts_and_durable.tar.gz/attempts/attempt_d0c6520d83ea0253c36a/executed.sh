#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/stdout.log
: > /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/approved.sh > /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/approved.sh > /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/stdout.log 2> /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_d0c6520d83ea0253c36a","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-partial_build/scratch/biomind-plan-local-graph-s348xj1t/task_outputs/fix-f6-partial_build/attempts/attempt_d0c6520d83ea0253c36a/exit_status.json
exit "$rc"
