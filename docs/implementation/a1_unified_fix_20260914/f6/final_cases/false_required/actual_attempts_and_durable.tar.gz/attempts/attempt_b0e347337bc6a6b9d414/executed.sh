#!/bin/bash
set +e
: > /tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/stdout.log
: > /tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/approved.sh > /tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/approved.sh > /tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/stdout.log 2> /tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_b0e347337bc6a6b9d414","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/exit_status.json.tmp.$$'
mv '/tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/exit_status.json.tmp.$$' /tmp/biomind-f6-candidate08-false_required/scratch/biomind-plan-local-graph-k5ndhum9/task_outputs/fix-f6-false_required/attempts/attempt_b0e347337bc6a6b9d414/exit_status.json
exit "$rc"
