#!/bin/bash
set +e
: > /tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/stdout.log
: > /tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/approved.sh > /tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/command_trace.log
/usr/bin/bash -o pipefail /tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/approved.sh > /tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/stdout.log 2> /tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_91cd26487054dd46b6a3","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/exit_status.json.tmp.$$'
mv '/tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/exit_status.json.tmp.$$' /tmp/biomind-generate-class-20260915/final10/v2_hooks/scratch/biomind-plan-local-graph-gipsm8vw/task_outputs/fix-f6-false_required/attempts/attempt_91cd26487054dd46b6a3/exit_status.json
exit "$rc"
