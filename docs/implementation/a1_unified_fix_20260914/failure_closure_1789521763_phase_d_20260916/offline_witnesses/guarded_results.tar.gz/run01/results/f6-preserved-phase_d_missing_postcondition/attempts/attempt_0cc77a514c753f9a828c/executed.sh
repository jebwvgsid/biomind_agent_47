#!/bin/bash
set +e
: > /tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/stdout.log
: > /tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/stderr.log
printf 'runner=%s script=%s\n' '/usr/bin/bash -o pipefail' /tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/approved.sh > /tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/command_trace.log
/usr/bin/bash -o pipefail /tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/approved.sh > /tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/stdout.log 2> /tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/stderr.log
rc=$?
printf 'returncode=%s\n' "$rc" >> /tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/command_trace.log
finished_at=$(date -Iseconds 2>/dev/null || date)
printf '{"attempt_id":"attempt_0cc77a514c753f9a828c","returncode":%s,"finished_at":"%s"}\n' "$rc" "$finished_at" > '/tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/exit_status.json.tmp.$$'
mv '/tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/exit_status.json.tmp.$$' /tmp/bm_failure_closure_d_run01/results/scratch/biomind-plan-local-graph-9awiwlxq/task_outputs/fix-f6-phase_d_missing_postcondition/attempts/attempt_0cc77a514c753f9a828c/exit_status.json
exit "$rc"
